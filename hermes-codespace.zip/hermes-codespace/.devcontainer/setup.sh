#!/usr/bin/env bash
# Runs once when the Codespace is created. Stops on first failure.
set -euo pipefail
cd "$(dirname "$0")/.."

ok()   { echo -e "[\e[32mOK\e[0m] $1"; }
fail() { echo -e "[\e[31mFAIL\e[0m] $1"; exit 1; }

echo "== Hermes Codespace setup =="
echo "OS: $(. /etc/os-release && echo "$PRETTY_NAME")"

command -v python3 >/dev/null && ok "Python $(python3 --version | cut -d' ' -f2)" || fail "Python missing"
command -v node    >/dev/null && ok "Node.js $(node --version)" || fail "Node.js missing"

pip install -q -r requirements.txt || fail "Python dependencies"
ok "Python dependencies"

python3 -m playwright install chromium >/dev/null || fail "Chromium install"
ok "Browser (Chromium)"

# Hermes install. Override HERMES_INSTALL_CMD if the upstream installer changes.
HERMES_INSTALL_CMD="${HERMES_INSTALL_CMD:-curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash}"
if ! command -v hermes >/dev/null; then
  bash -c "$HERMES_INSTALL_CMD" || fail "Hermes install"
  export PATH="$HOME/.local/bin:$PATH"
fi
command -v hermes >/dev/null && ok "Hermes" || fail "Hermes not on PATH"

python3 - <<'PY' || fail "Browser automation"
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True); b.new_page().goto("about:blank"); b.close()
PY
ok "Browser automation"

[ -f config/.env ] || cp config/config.example.env config/.env
ok "Environment configuration (config/.env)"

# Pass provider keys through to Hermes' own config (~/.hermes/.env)
mkdir -p "$HOME/.hermes"; touch "$HOME/.hermes/.env"; chmod 600 "$HOME/.hermes/.env"
for k in GEMINI_API_KEY OPENROUTER_API_KEY; do
  v="${!k:-}"; [ -z "$v" ] && continue
  sed -i "/^$k=/d" "$HOME/.hermes/.env"; echo "$k=$v" >> "$HOME/.hermes/.env"
  [ "$k" = GEMINI_API_KEY ] && { sed -i "/^GOOGLE_API_KEY=/d" "$HOME/.hermes/.env"; echo "GOOGLE_API_KEY=$v" >> "$HOME/.hermes/.env"; }
  ok "$k passed to Hermes"
done

chmod +x scripts/*.sh
echo "Setup complete. Run: scripts/start-hermes.sh"
